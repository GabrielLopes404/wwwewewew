import { Card } from "@/components/ui/card";
import { 
  TrendingUp, 
  Users, 
  FileText, 
  BarChart3, 
  Shield, 
  Zap 
} from "lucide-react";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const benefits = [
  {
    icon: TrendingUp,
    title: "Gestão Financeira Completa",
    description: "Controle total de receitas, despesas e fluxo de caixa em tempo real. Visualize suas métricas financeiras de forma clara e objetiva.",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    icon: Users,
    title: "Gestão de Clientes",
    description: "Organize seus clientes, histórico de transações e documentos em um só lugar. Relacionamento profissional e eficiente.",
    gradient: "from-purple-500 to-pink-500"
  },
  {
    icon: FileText,
    title: "Faturas Inteligentes",
    description: "Crie, envie e acompanhe faturas profissionais. Controle de vencimentos e pagamentos automático.",
    gradient: "from-green-500 to-emerald-500"
  },
  {
    icon: BarChart3,
    title: "Relatórios e Analytics",
    description: "Dashboards personalizados com métricas importantes: MRR, ARR, taxa de conversão e muito mais.",
    gradient: "from-orange-500 to-red-500"
  },
  {
    icon: Shield,
    title: "Segurança Empresarial",
    description: "Seus dados protegidos com criptografia de nível bancário. Backups automáticos e recuperação de desastres.",
    gradient: "from-indigo-500 to-purple-500"
  },
  {
    icon: Zap,
    title: "Automação Inteligente",
    description: "Automatize cobranças, lembretes de pagamento e reconciliação bancária. Foque no que importa.",
    gradient: "from-yellow-500 to-orange-500"
  }
];

export default function BenefitsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section id="beneficios" className="relative py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background via-muted/20 to-background overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(59,130,246,0.05),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(139,92,246,0.05),transparent_50%)]" />
      
      <div ref={ref} className="max-w-[1280px] mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="inline-block mb-4"
          >
            <span className="px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-sm font-medium text-primary">
              Recursos Premium
            </span>
          </motion.div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-semibold mb-4 bg-gradient-to-r from-foreground via-foreground to-foreground/70 bg-clip-text text-transparent" data-testid="text-benefits-title">
            Tudo que você precisa para crescer
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="text-benefits-subtitle">
            Ferramentas profissionais para gestão financeira completa da sua empresa
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.1 * index, duration: 0.6 }}
            >
              <Card 
                className="relative p-8 group hover-elevate transition-all duration-500 overflow-hidden border-primary/10 backdrop-blur-sm bg-card/50"
                data-testid={`card-benefit-${index}`}
              >
                <motion.div
                  className={`absolute -inset-px bg-gradient-to-r ${benefit.gradient} rounded-lg opacity-0 group-hover:opacity-10 blur transition-opacity duration-500`}
                  whileHover={{ scale: 1.05 }}
                />
                
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring", stiffness: 300, damping: 10 }}
                  className="relative z-10"
                >
                  <div className={`h-14 w-14 rounded-xl bg-gradient-to-br ${benefit.gradient} p-0.5 mb-6 group-hover:shadow-2xl transition-all duration-500`}>
                    <div className="h-full w-full rounded-xl bg-card flex items-center justify-center group-hover:bg-transparent transition-colors duration-500">
                      <benefit.icon className="h-7 w-7 text-primary group-hover:text-white transition-colors duration-500" />
                    </div>
                  </div>
                </motion.div>

                <h3 className="text-xl font-semibold mb-3 relative z-10 group-hover:text-primary transition-colors duration-300" data-testid={`text-benefit-title-${index}`}>
                  {benefit.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed relative z-10" data-testid={`text-benefit-description-${index}`}>
                  {benefit.description}
                </p>

                <motion.div
                  className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent"
                  initial={{ scaleX: 0 }}
                  whileHover={{ scaleX: 1 }}
                  transition={{ duration: 0.3 }}
                />
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
